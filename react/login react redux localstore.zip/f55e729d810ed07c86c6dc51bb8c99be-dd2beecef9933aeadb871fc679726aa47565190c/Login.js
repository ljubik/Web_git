// components/Login/Login.js

class Login extends Component {
  
  // ...
  
  handleSubmit(evt) {
    evt.preventDefault();
    this.props.mutate(this.state)
      .then(({ data }) => {
        this.handleLogin(data);
      }).catch((error) => {
        this.setState({password: null, error: true});
        console.warn('there was an error sending the query', error);
      }); 
  }

  handleLogin(data){
    const { result } = data;
    if (result && result.token) {
      this.setState({error: false});
      this.props.setCurrentApiToken(result.token);
    }

    if (this.state.error) {
      this.refs.password.focus();
    }
  }
  
  // ...
  
}