// actions/currentApiToken.js

import { SET_CURRENT_API_TOKEN, UNSET_CURRENT_API_TOKEN } from '../constants/EventTypes';

export function setCurrentApiToken(value) {
  let action = {
    type: SET_CURRENT_API_TOKEN,
    value: value
  };
  return action;
}

export function unsetCurrentApiToken(value) {
  let action = {
    type: UNSET_CURRENT_API_TOKEN,
    value: value
  };
  return action;
}
