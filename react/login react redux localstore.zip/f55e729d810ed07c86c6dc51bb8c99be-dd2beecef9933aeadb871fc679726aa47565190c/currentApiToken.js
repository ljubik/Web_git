// reducers/currentApiToken.js

import { browserHistory } from 'react-router';
import { SET_CURRENT_API_TOKEN, UNSET_CURRENT_API_TOKEN } from '../constants/EventTypes';
import { API_TOKEN } from '../constants/LocalStorage';

const initialState = localStorage.getItem(API_TOKEN);

export default function(state = initialState, event) {
  switch (event.type) {
  case SET_CURRENT_API_TOKEN:
    localStorage.setItem(API_TOKEN, event.value);
    window.location = "/";
    return event.value;
  case UNSET_CURRENT_API_TOKEN:
    localStorage.removeItem(API_TOKEN);
    window.location = "/";
    return initialState;
  default:
    return state;
  }
}
