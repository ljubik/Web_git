# react-router-course-ru
Код для раздела [Подтверждение перехода](https://maxfarseer.gitbooks.io/react-router-course-ru/content/podtverzhdenie_perehoda.html)
