// flow-typed signature: 28ad27471ba2cb831af6a1f17b7f0cf0
// flow-typed version: f3161dc07c/isomorphic-fetch_v2.x.x/flow_>=v0.25.x


declare module 'isomorphic-fetch' {
    declare module.exports: (input: string | Request, init?: RequestOptions) => Promise<Response>;
}
