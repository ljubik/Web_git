## About
This is a basic forms demo built using React. The application demonstrates how React components can be used to construct forms. The components in the demonstration are reusable. 
To install the demo, you will need to 
1. Clone the repo
2. Install the dependencies by running `yarn`.
3. Start the server: `yarn start`
4. Happy hacking!
