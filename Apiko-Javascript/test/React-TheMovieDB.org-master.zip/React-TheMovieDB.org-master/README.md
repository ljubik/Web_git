# REACT - THEMOVIEDB.ORG
## Install and Run locally
```
-- npm i --
-- npm start --
```
## Introduction of the Web-App
This is a simple web-app use React as a front-end.
The data-base was used by themoviedb.org.
You can login and get API key. Code is in 'config.js' file

## About the movie App
You can search the movie's name. Find some new movie.
