import React from 'react';
import PropTypes from 'prop-types';
import './Spinner.css'

const Spinner = ({}) => {
  return (
    <div className="loader"></div>
  );
}

// Spinner.propTypes = {
//   : PropTypes.
// };

export default Spinner;
