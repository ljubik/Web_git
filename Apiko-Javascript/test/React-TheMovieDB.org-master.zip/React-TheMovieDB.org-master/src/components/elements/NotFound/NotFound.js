import React from 'react';

const NotFound = ({}) => {
  return (
    <div>
      <h1 style={{textAlign: 'center', margin: '16px'}}>Uuh oh, 😥  Not Found this page - Check your link please!</h1>
    </div>
  );
}

export default NotFound;
