# cursomscd-pelis
Curso MSCD: Proyecto Películas con el api themoviedb.org

### Javascript
### Jquery
### CSS3
### HTML5